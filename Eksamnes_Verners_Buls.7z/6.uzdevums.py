vards = input("Ievadiet vārdu: ")
izvade = vards[::-1]
print("Izvade:", izvade)
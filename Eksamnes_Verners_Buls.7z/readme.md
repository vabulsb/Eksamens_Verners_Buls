Laime nav zvaniņš, kas zvana,
Laime nav dimants, kas mirdz.
Laime ir nezūdošs sapnis,
Patiesa cilvēka sirds.

Nekas nesanāk

numbers = [999999999, 88888888, 7777777, 666666, 55555]

for number in numbers:
    print(number)
import math

# Ievade riņķa rādiusa
radius = int(input("Ievadiet riņķa rādiusu (vesels skaitlis): "))

# Aprēķins riņķa laukumam
area = math.pi * radius**2

# Izvade riņķa laukumam
print("Riņķa laukums ir:", area)
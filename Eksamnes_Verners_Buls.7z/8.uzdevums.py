preces = ["olas", "krejums", "sviests", "biezpiens", "kefirs"]

print("Pirmais elements:", preces[0])
print("Pēdējais elements:", preces[-1])
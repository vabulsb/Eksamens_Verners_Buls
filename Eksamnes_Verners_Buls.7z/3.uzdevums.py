print("Man viss izdodas!")
